var searchData=
[
  ['cancel',['cancel',['../structwl__touch__listener.html#a455d5080d9b38588b701731c56ae3143',1,'wl_touch_listener']]],
  ['cancel_5fread',['cancel_read',['../wayland-client_8c.html#aecb2c6ef9ff0dac77feaf335ed3355aa',1,'wayland-client.c']]],
  ['cancelled',['cancelled',['../structwl__data__source__listener.html#a029f07596040496affb4ef6c44c3f525',1,'wl_data_source_listener']]],
  ['capabilities',['capabilities',['../structwl__seat__listener.html#a2d05701aa6cdc40a4218604e41c10523',1,'wl_seat_listener']]],
  ['configure',['configure',['../structwl__shell__surface__listener.html#adb4bda9fbc17bc5a7e4fb3181ada015d',1,'wl_shell_surface_listener']]],
  ['connect_5fto_5fsocket',['connect_to_socket',['../wayland-client_8c.html#a668d6e13d9e38a88714ad7aff62d0470',1,'wayland-client.c']]],
  ['create_5foutgoing_5fproxy',['create_outgoing_proxy',['../wayland-client_8c.html#a6cfa44e7150322e701f16ce6402abfe4',1,'wayland-client.c']]],
  ['create_5fproxies',['create_proxies',['../wayland-client_8c.html#aaa8ffbde783348fb8909f549e93659e1',1,'wayland-client.c']]]
];
