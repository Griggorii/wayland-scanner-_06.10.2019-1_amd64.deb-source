var searchData=
[
  ['queue_5fevent',['queue_event',['../wayland-client_8c.html#a715a48789d2169f202773826564c3313',1,'wayland-client.c']]]
];
