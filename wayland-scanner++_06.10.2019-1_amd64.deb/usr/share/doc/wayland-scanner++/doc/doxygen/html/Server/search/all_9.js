var searchData=
[
  ['i',['i',['../unionwl__argument.html#ad64fd62947e029bd77e4ff1f7ec0b6f7',1,'wl_argument']]],
  ['id',['id',['../structwl__display.html#a864360d97771499c07e33a4ba3948bf7',1,'wl_display::id()'],['../structwl__object.html#a96193ebafbba8785e03ff9dd8e39d30c',1,'wl_object::id()']]],
  ['idle_5fsource_5finterface',['idle_source_interface',['../event-loop_8c.html#a2712406e30c446d995910f005cdd0599',1,'event-loop.c']]],
  ['implementation',['implementation',['../structwl__object.html#a7478578f273f986624ecc26acfd4e6c2',1,'wl_object']]],
  ['init_5fsigbus_5fdata_5fkey',['init_sigbus_data_key',['../wayland-shm_8c.html#a34c4446bdaf2452ef114613a06427766',1,'wayland-shm.c']]],
  ['interface',['interface',['../structwl__global.html#ae1d0a630338a47aab0af3c3a00a31459',1,'wl_global::interface()'],['../structwl__object.html#af663788be73eae7d567f044f8f9cbfb9',1,'wl_object::interface()']]],
  ['internal_5frefcount',['internal_refcount',['../structwl__shm__pool.html#ab3b7954e5221998a8052a5dcbadd0b94',1,'wl_shm_pool']]],
  ['it',['it',['../structwl__resource__iterator__context.html#aba992bce2ad676ddea0234e51d5ec79d',1,'wl_resource_iterator_context']]]
];
