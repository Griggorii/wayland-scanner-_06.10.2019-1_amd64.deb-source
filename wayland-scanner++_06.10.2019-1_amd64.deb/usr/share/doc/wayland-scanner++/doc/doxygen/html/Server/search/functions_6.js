var searchData=
[
  ['init_5fsigbus_5fdata_5fkey',['init_sigbus_data_key',['../wayland-shm_8c.html#a34c4446bdaf2452ef114613a06427766',1,'wayland-shm.c']]]
];
