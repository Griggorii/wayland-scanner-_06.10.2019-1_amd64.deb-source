var searchData=
[
  ['prepare_5fzombie',['prepare_zombie',['../wayland-client_8c.html#a1759edc352d6378a73c6cc0199216814',1,'wayland-client.c']]],
  ['proxy_5fcreate',['proxy_create',['../wayland-client_8c.html#a975a51f5b5bf3adfc83f318da0237d43',1,'wayland-client.c']]],
  ['proxy_5fdestroy',['proxy_destroy',['../wayland-client_8c.html#a832fd28eed8006b3268302ba4f663d87',1,'wayland-client.c']]]
];
