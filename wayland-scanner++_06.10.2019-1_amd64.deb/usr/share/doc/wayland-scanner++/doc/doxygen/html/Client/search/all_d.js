var searchData=
[
  ['n',['n',['../unionwl__argument.html#ad144c37a3e88e92243829a71953f5292',1,'wl_argument']]],
  ['name',['name',['../structwl__message.html#a0def81dbfe6ee21dcf1b6ac037badda7',1,'wl_message::name()'],['../structwl__interface.html#a3ee0780631cad42bcc90a8deb76caec8',1,'wl_interface::name()'],['../structwl__seat__listener.html#a2289aff4263de68305468de1732da77a',1,'wl_seat_listener::name()']]],
  ['next',['next',['../structwl__list.html#aa0454596900ed769fb2f033fbb96bf2c',1,'wl_list']]]
];
