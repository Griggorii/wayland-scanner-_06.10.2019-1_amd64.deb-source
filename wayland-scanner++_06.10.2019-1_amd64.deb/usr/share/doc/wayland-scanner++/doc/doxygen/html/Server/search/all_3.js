var searchData=
[
  ['client',['client',['../structwl__resource.html#a6ceb1559a387f584ac68c5ccff744b70',1,'wl_resource']]],
  ['client_5flist',['client_list',['../structwl__display.html#a4a646a3a3a91ed8797c3353c79a802c1',1,'wl_display']]],
  ['commit',['commit',['../structwl__surface__interface.html#a1d489da71a2bd773d009c11bd832bf4c',1,'wl_surface_interface']]],
  ['connection',['connection',['../structwl__client.html#a2b9ba402199671abbd4f7d7ad36b31f8',1,'wl_client']]],
  ['create_5fbuffer',['create_buffer',['../structwl__shm__pool__interface.html#a48e6a1100ac47f9be485c5475276bc8f',1,'wl_shm_pool_interface']]],
  ['create_5fclient_5fsignal',['create_client_signal',['../structwl__display.html#af4eb55355f6bba19c2c4d519fa9a770e',1,'wl_display']]],
  ['create_5fdata_5fsource',['create_data_source',['../structwl__data__device__manager__interface.html#ace3764fe1f6f96e27e6dc1f4e032347a',1,'wl_data_device_manager_interface']]],
  ['create_5fpool',['create_pool',['../structwl__shm__interface.html#ab5a401abe6493a24e7cb437672347847',1,'wl_shm_interface']]],
  ['create_5fregion',['create_region',['../structwl__compositor__interface.html#a57792f35c22dba2e5fe0df7fd06d49c1',1,'wl_compositor_interface']]],
  ['create_5fsurface',['create_surface',['../structwl__compositor__interface.html#af96e306877a7bf7717d61dc0734a5924',1,'wl_compositor_interface']]],
  ['current_5fpool',['current_pool',['../structwl__shm__sigbus__data.html#aaa529b50c8bda30bd5229e79e88fe658',1,'wl_shm_sigbus_data']]]
];
