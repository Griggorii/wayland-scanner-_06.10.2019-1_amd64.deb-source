var searchData=
[
  ['destroy_5fqueued_5fclosure',['destroy_queued_closure',['../wayland-client_8c.html#a1994f0743c26a1d5296c52ce6607be1b',1,'wayland-client.c']]],
  ['dispatch_5fevent',['dispatch_event',['../wayland-client_8c.html#ab2a9700cc9f503141d1cdcf4f2900e6c',1,'wayland-client.c']]],
  ['dispatch_5fqueue',['dispatch_queue',['../wayland-client_8c.html#a52d2f76083fe36d43f841afe4e89ce52',1,'wayland-client.c']]],
  ['display_5ffatal_5ferror',['display_fatal_error',['../wayland-client_8c.html#a7d1d1f61c788a96d7a47a16c51829364',1,'wayland-client.c']]],
  ['display_5fhandle_5fdelete_5fid',['display_handle_delete_id',['../wayland-client_8c.html#a9abb27ef704a732ad0f76382a1bfc028',1,'wayland-client.c']]],
  ['display_5fhandle_5ferror',['display_handle_error',['../wayland-client_8c.html#aa6f65f73a943e2da02f1c10f3cdb6501',1,'wayland-client.c']]],
  ['display_5fprotocol_5ferror',['display_protocol_error',['../wayland-client_8c.html#ae8106740fdd8559e7629488d87adf5c2',1,'wayland-client.c']]],
  ['display_5fwakeup_5fthreads',['display_wakeup_threads',['../wayland-client_8c.html#a2b3463de96f4f0840eb321d10f0729ce',1,'wayland-client.c']]]
];
