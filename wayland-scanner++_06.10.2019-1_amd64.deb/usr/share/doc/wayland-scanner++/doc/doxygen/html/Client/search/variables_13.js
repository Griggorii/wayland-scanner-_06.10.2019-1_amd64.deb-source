var searchData=
[
  ['version',['version',['../structwl__interface.html#ac7b9bc6c0352b4100213109094ca55fa',1,'wl_interface']]]
];
