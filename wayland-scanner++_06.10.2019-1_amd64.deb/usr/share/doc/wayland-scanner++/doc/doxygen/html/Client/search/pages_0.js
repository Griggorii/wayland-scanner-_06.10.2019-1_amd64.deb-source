var searchData=
[
  ['the_20wayland_20protocol',['The wayland protocol',['../page_wayland.html',1,'']]]
];
