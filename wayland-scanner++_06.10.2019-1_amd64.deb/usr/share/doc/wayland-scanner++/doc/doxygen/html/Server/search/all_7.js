var searchData=
[
  ['get_5fdata_5fdevice',['get_data_device',['../structwl__data__device__manager__interface.html#a0cb1a63dae598970957339249fa6c16c',1,'wl_data_device_manager_interface']]],
  ['get_5fkeyboard',['get_keyboard',['../structwl__seat__interface.html#a351de9b6ed9e309870cfb2a718b31a98',1,'wl_seat_interface']]],
  ['get_5fpointer',['get_pointer',['../structwl__seat__interface.html#ad23b1401d2957190a63dd60ff47ff1f5',1,'wl_seat_interface']]],
  ['get_5fregistry',['get_registry',['../structwl__display__interface.html#aecf6ae43c6d81959e879ed814f08c706',1,'wl_display_interface']]],
  ['get_5fshell_5fsurface',['get_shell_surface',['../structwl__shell__interface.html#a4475216c4976d551538cd35243bf26d0',1,'wl_shell_interface']]],
  ['get_5fsubsurface',['get_subsurface',['../structwl__subcompositor__interface.html#a76e0f64f069358abb5b9545f3b2e7516',1,'wl_subcompositor_interface']]],
  ['get_5ftouch',['get_touch',['../structwl__seat__interface.html#a7af5627017034bcb5aafa1127da55c67',1,'wl_seat_interface']]],
  ['global_5ffilter',['global_filter',['../structwl__display.html#ab8546912b40cbd9a27db5483cdf4adf0',1,'wl_display']]],
  ['global_5ffilter_5fdata',['global_filter_data',['../structwl__display.html#a4fe5fcd6fefd4a542c18e2426c3ce47b',1,'wl_display']]],
  ['global_5flist',['global_list',['../structwl__display.html#a8eafb443ae6bcbf1ee8fc227aa5c1694',1,'wl_display']]]
];
