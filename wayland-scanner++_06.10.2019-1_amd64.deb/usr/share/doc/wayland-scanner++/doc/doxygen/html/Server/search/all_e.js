var searchData=
[
  ['place_5fabove',['place_above',['../structwl__subsurface__interface.html#a46ef0549b1246f705b9349b9718f33ff',1,'wl_subsurface_interface']]],
  ['place_5fbelow',['place_below',['../structwl__subsurface__interface.html#a7d8ccb7576af23b8db5b05fd5f8a7fde',1,'wl_subsurface_interface']]],
  ['pong',['pong',['../structwl__shell__surface__interface.html#a40effd64e32475e13538c5b331b2c7c4',1,'wl_shell_surface_interface']]],
  ['pool',['pool',['../structwl__shm__buffer.html#a16f66addfe9b94906e8a0bf21653b81b',1,'wl_shm_buffer']]],
  ['post_5fdispatch_5fcheck',['post_dispatch_check',['../event-loop_8c.html#a1808bd53877bffa153f58d64152003a7',1,'event-loop.c']]],
  ['prev',['prev',['../structwl__list.html#a72c2827d3103691f9e3299babfbf0704',1,'wl_list']]],
  ['protocol_5floggers',['protocol_loggers',['../structwl__display.html#a662a3081bed0349619bc7fe952fbb903',1,'wl_display']]]
];
