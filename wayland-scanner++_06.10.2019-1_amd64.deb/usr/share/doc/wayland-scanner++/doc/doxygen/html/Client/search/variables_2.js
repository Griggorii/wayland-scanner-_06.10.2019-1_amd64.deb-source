var searchData=
[
  ['cancel',['cancel',['../structwl__touch__listener.html#a455d5080d9b38588b701731c56ae3143',1,'wl_touch_listener']]],
  ['cancelled',['cancelled',['../structwl__data__source__listener.html#a029f07596040496affb4ef6c44c3f525',1,'wl_data_source_listener']]],
  ['capabilities',['capabilities',['../structwl__seat__listener.html#a2d05701aa6cdc40a4218604e41c10523',1,'wl_seat_listener']]],
  ['configure',['configure',['../structwl__shell__surface__listener.html#adb4bda9fbc17bc5a7e4fb3181ada015d',1,'wl_shell_surface_listener']]]
];
