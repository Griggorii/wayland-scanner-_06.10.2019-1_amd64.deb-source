var searchData=
[
  ['increase_5fclosure_5fargs_5frefcount',['increase_closure_args_refcount',['../wayland-client_8c.html#a0ca8d7b82eefb523a30166ce91118735',1,'wayland-client.c']]]
];
