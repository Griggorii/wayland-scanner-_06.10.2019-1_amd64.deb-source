var searchData=
[
  ['receive',['receive',['../structwl__data__offer__interface.html#aef4f2510405b9e60236c838f0daf94d4',1,'wl_data_offer_interface']]],
  ['registry_5fbind',['registry_bind',['../wayland-server_8c.html#a544722ec6870ffc3b1710e372a6a2ca0',1,'wayland-server.c']]],
  ['registry_5finterface',['registry_interface',['../wayland-server_8c.html#aa4c206ce0f7af5d09e5fe6506cfeabd7',1,'wayland-server.c']]],
  ['registry_5fresource_5flist',['registry_resource_list',['../structwl__display.html#adacf20b879ad10677d0442c3a5469923',1,'wl_display']]],
  ['release',['release',['../structwl__data__device__interface.html#abe19f7d63a1aee3ef38df8389ed68727',1,'wl_data_device_interface::release()'],['../structwl__seat__interface.html#a7de44bb679e65806ab988c23111cf200',1,'wl_seat_interface::release()'],['../structwl__pointer__interface.html#a3bfb28e4f0523db3a4426c94eccd1bf2',1,'wl_pointer_interface::release()'],['../structwl__keyboard__interface.html#ac8726477b539dc80b9bd93a88a95b031',1,'wl_keyboard_interface::release()'],['../structwl__touch__interface.html#a263f7e92155933cd84ac9cd1b3710ae9',1,'wl_touch_interface::release()'],['../structwl__output__interface.html#aa7a6f13549c5b2c40d34a90fd2b692dc',1,'wl_output_interface::release()']]],
  ['reraise_5fsigbus',['reraise_sigbus',['../wayland-shm_8c.html#a4e19e7e2d179139ddb6545300b4770c1',1,'wayland-shm.c']]],
  ['resize',['resize',['../structwl__shm__pool__interface.html#a09d3eaa5f16f9d212844c29fb37288dc',1,'wl_shm_pool_interface::resize()'],['../structwl__shell__surface__interface.html#a7a4a383e4777a27fbb7ecf20b3e439c9',1,'wl_shell_surface_interface::resize()']]],
  ['resource',['resource',['../structwl__protocol__logger__message.html#ac76d15d9c58adf12cb6f2586ee3bea2f',1,'wl_protocol_logger_message::resource()'],['../structwl__shm__pool.html#a828e8a2c88c2e7b37c98df767aed9909',1,'wl_shm_pool::resource()'],['../structwl__shm__buffer.html#a3d12a4cd03248384cc49f1967344f046',1,'wl_shm_buffer::resource()']]],
  ['resource_5fcreated_5fsignal',['resource_created_signal',['../structwl__client.html#adf241e87b420a24141f11cafc589bd5c',1,'wl_client']]],
  ['resource_5fis_5fdeprecated',['resource_is_deprecated',['../wayland-server_8c.html#a8783de35d9cb8c7ce05efc716ce1a31a',1,'wayland-server.c']]],
  ['resource_5fiterator_5fhelper',['resource_iterator_helper',['../wayland-server_8c.html#a82b2c8234e539210317a2eeb440696e6',1,'wayland-server.c']]],
  ['run',['run',['../structwl__display.html#aef9cf1c5f1b4fcaa4d7607bd82d0a093',1,'wl_display']]]
];
