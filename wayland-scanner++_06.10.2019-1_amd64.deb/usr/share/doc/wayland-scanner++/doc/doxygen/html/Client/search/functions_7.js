var searchData=
[
  ['read_5fevents',['read_events',['../wayland-client_8c.html#aed466af5f7b3d5f35a1291b2a1363c2a',1,'wayland-client.c']]]
];
