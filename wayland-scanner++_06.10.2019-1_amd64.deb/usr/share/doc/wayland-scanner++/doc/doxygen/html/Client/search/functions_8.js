var searchData=
[
  ['sync_5fcallback',['sync_callback',['../wayland-client_8c.html#ab1d6da2ed7c02f7b2e716084caca51c2',1,'wayland-client.c']]]
];
