var searchData=
[
  ['cancel_5fread',['cancel_read',['../wayland-client_8c.html#aecb2c6ef9ff0dac77feaf335ed3355aa',1,'wayland-client.c']]],
  ['connect_5fto_5fsocket',['connect_to_socket',['../wayland-client_8c.html#a668d6e13d9e38a88714ad7aff62d0470',1,'wayland-client.c']]],
  ['create_5foutgoing_5fproxy',['create_outgoing_proxy',['../wayland-client_8c.html#a6cfa44e7150322e701f16ce6402abfe4',1,'wayland-client.c']]],
  ['create_5fproxies',['create_proxies',['../wayland-client_8c.html#aaa8ffbde783348fb8909f549e93659e1',1,'wayland-client.c']]]
];
