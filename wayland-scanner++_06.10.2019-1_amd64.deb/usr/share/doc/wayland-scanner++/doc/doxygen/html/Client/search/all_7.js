var searchData=
[
  ['geometry',['geometry',['../structwl__output__listener.html#a78ab10c593e6545157ee9be9b250c0e9',1,'wl_output_listener']]],
  ['global',['global',['../structwl__registry__listener.html#a7da47d26f25716257f73a635ddc9e12c',1,'wl_registry_listener']]],
  ['global_5fremove',['global_remove',['../structwl__registry__listener.html#ab7e5349ccfb9dfe3100f08092c8658eb',1,'wl_registry_listener']]]
];
