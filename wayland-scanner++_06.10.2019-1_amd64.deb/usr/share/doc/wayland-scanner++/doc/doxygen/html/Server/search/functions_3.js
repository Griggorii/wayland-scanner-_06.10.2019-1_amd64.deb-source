var searchData=
[
  ['destroy_5fbuffer',['destroy_buffer',['../wayland-shm_8c.html#a7231b52c0ce2a7b81ef6de09bdb6b16e',1,'wayland-shm.c']]],
  ['destroy_5fclient_5fdisplay_5fresource',['destroy_client_display_resource',['../wayland-server_8c.html#ace2b4e94afe6d7573eacd92fd28e450e',1,'wayland-server.c']]],
  ['destroy_5fclient_5fwith_5ferror',['destroy_client_with_error',['../wayland-server_8c.html#afc723baaad062678a5cb1366472ba84a',1,'wayland-server.c']]],
  ['destroy_5fpool',['destroy_pool',['../wayland-shm_8c.html#a487ba3577d701baee7f40d651bafc2c8',1,'wayland-shm.c']]],
  ['destroy_5fresource',['destroy_resource',['../wayland-server_8c.html#a942be7eb6c103bab38bac6f3b608e013',1,'wayland-server.c']]],
  ['destroy_5fsigbus_5fdata',['destroy_sigbus_data',['../wayland-shm_8c.html#aa19bb87954d9ecde011a7d82f414fc7d',1,'wayland-shm.c']]],
  ['display_5fget_5fregistry',['display_get_registry',['../wayland-server_8c.html#a5a6e0098b0e0f468a7a392873e268caa',1,'wayland-server.c']]],
  ['display_5fsync',['display_sync',['../wayland-server_8c.html#ab959fd43e51921133cd16adb7c78f93b',1,'wayland-server.c']]]
];
