var searchData=
[
  ['unix_5fpath_5fmax',['UNIX_PATH_MAX',['../wayland-server_8c.html#a7baab2aa5bf8eb14b6128e0f16634837',1,'wayland-server.c']]]
];
